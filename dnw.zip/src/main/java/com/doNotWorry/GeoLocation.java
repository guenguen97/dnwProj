//package com.doNotWorry;
//
//
//import jakarta.persistence.Entity;
//import lombok.Getter;
//import lombok.Setter;
//
//@Entity
//@Setter
//@Getter
//public class GeoLocation {
//
//    private double latitude;
//    private double longitude;
//
//    public GeoLocation(double latitude, double longitude) {
//        this.latitude = latitude;
//        this.longitude = longitude;
//    }
//
//    // 게터와 세터
//}
