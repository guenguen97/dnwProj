package com.doNotWorry;

public class ApiResponse {

    private String apiKey;

    public ApiResponse(String apiKey) {
        this.apiKey = apiKey;
    }

    public String getApiKey() {
        return apiKey;
    }
}
